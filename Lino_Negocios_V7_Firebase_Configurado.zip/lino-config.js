// Configuración pública de Firebase para Lino Negocios.
export const firebaseConfig = {
  apiKey: 'AIzaSyD3_lPED7ZYnxP-t9t8DA7k0YRN5ipxnQ8',
  authDomain: 'lino-negocios.firebaseapp.com',
  projectId: 'lino-negocios',
  storageBucket: 'lino-negocios.firebasestorage.app',
  messagingSenderId: '175162015205',
  appId: '1:175162015205:web:5ad7dbdccc64bba0fe430c'
};
// Lista de correos de acceso para la DEMOSTRACIÓN, no control de seguridad de servidor.
export const allowedEmails = ['alexandratena1803@gmail.com'];
